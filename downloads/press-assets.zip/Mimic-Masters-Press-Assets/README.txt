MIMIC MASTERS - PRESS ASSETS
============================
Developer: Alvie Spurlock, March Hare Games
Website:   https://alviespurlock.github.io/MimicMastersWebsite/
Contact:   https://alviespurlock.github.io/MimicMastersWebsite/contact.html
Email:     madteapartydevelopment@outlook.com
YouTube:   https://www.youtube.com/@Hatters_Mania (business) | https://www.youtube.com/@HattersMania (personal)
Twitch:    https://www.twitch.tv/hattersmania
Discord:   https://discord.gg/3SWjw83hHQ

CONTENTS
Logos/        Mimic Masters and March Hare Games logos, 1024x1024 PNG.
              "Transparent" files have no background; "Full" and "Background" files include one.
Mode-Icons/   Icons for Battle For Time, Cadence Tracker, Elemental Bash, Parry Madness,
              Quantum Overload and Shuffle Board, 1080x1080 PNG with transparency.
              (Classic uses the main Mimic Masters logo.)
Screenshots/  Full-resolution gameplay screenshots (JPG, high quality), 5 each for
              Classic, Cadence Tracker, Elemental Bash and Parry Madness.
Videos/       Vertical gameplay previews, MP4 (886x1920): one per mode above plus Game Preview 1 and 2.

More modes will be added as screenshots and footage become available.
