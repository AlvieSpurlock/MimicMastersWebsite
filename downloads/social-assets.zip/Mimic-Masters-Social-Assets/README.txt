MIMIC MASTERS - SOCIAL ASSETS
=============================
Developer: Alvie Spurlock, March Hare Games
Website:   https://alviespurlock.github.io/MimicMastersWebsite/
Contact:   https://alviespurlock.github.io/MimicMastersWebsite/contact.html
Email:     madteapartydevelopment@outlook.com
YouTube:   https://www.youtube.com/@Hatters_Mania (business) | https://www.youtube.com/@HattersMania (personal)
Twitch:    https://www.twitch.tv/hattersmania
Discord:   https://discord.gg/3SWjw83hHQ

CONTENTS
Logos/        Mimic Masters and March Hare Games logos, 1024x1024 PNG (transparent and background versions).
Mode-Icons/   Icons for six game modes, 1024x1024 PNG with transparency (Classic uses the main logo).
Screenshots/  Gameplay screenshots sized for posting (JPG, max 1350px tall), 5 each for
              Classic, Cadence Tracker, Elemental Bash and Parry Madness.
Videos/       Short vertical gameplay clips, MP4 (720px wide), ready to upload to social platforms.
